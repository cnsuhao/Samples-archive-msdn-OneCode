/****************************** Module Header ******************************\
* Module Name:  virtvol.c
* Project:      CppWDKVirtualVolume
* Copyright (c) Microsoft Corporation.
* 
* Abstract:
* 
* This is the Virtvol sample driver.  This version of the driver has been
* modified to support the driver frameworks. This driver basically creates
* a nonpaged pool and exposes that as a storage media. User can
* find the device in the disk manager and format the media to use
* as FAT or NTFS volume.
* 
* Environment:
* 
* Kernel mode only.
* 
* This source is subject to the Microsoft Public License.
* See http://www.microsoft.com/opensource/licenses.mspx#Ms-PL.
* All other rights reserved.
* 
* THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
* EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
\***************************************************************************/

#include "virtvol.h"
#include "ntintsafe.h"
#ifdef ALLOC_PRAGMA
#pragma alloc_text(INIT, DriverEntry)
#pragma alloc_text(PAGE, VirtVolEvtDeviceAdd)
#pragma alloc_text(PAGE, VirtVolEvtDeviceContextCleanup)
#pragma alloc_text(PAGE, VirtVolQueryVolumeRegParameters)
#pragma alloc_text(PAGE, VirtVolFormatVolume)
#endif
DECLARE_CONST_UNICODE_STRING( SDDL_DEVOBJ_SYS_ALL_ADM_ALL_WORLD_ALL_RES_ALL, L"D:P(A;;GA;;;SY)(A;;GA;;;BA)(A;;GA;;;WD)(A;;GA;;;RC)");
WDFWORKITEM g_WorkItemRegisterMountMgr = NULL;
ULONG ordinal = 1;
NTSTATUS DriverEntry(IN PDRIVER_OBJECT DriverObject, IN PUNICODE_STRING RegistryPath)
{
    WDF_DRIVER_CONFIG config;
    WDF_DRIVER_CONFIG_INIT( &config, VirtVolEvtDeviceAdd );
    config.EvtDriverUnload = VirtVolEvtDriverUnload;
    return WdfDriverCreate(DriverObject, RegistryPath, WDF_NO_OBJECT_ATTRIBUTES, &config, WDF_NO_HANDLE);
}

VOID VirtVolEvtIoRead(IN WDFQUEUE Queue, IN WDFREQUEST Request, IN size_t Length)
{
    PDEVICE_EXTENSION      devExt = QueueGetExtension(Queue)->DeviceExtension;
    NTSTATUS               Status = STATUS_INVALID_PARAMETER;
    WDF_REQUEST_PARAMETERS Parameters;
    LARGE_INTEGER          ByteOffset;
    WDFMEMORY              hMemory;
    __analysis_assume(Length > 0);
    WDF_REQUEST_PARAMETERS_INIT(&Parameters);
    WdfRequestGetParameters(Request, &Parameters);
    ByteOffset.QuadPart = Parameters.Parameters.Read.DeviceOffset;
    if (VirtVolCheckParameters(devExt, ByteOffset, Length)) {
        Status = WdfRequestRetrieveOutputMemory(Request, &hMemory);
        if(NT_SUCCESS(Status)){
            Status = WdfMemoryCopyFromBuffer(hMemory, 0, devExt->VolumeImage + ByteOffset.LowPart, Length);
        }
    }
    WdfRequestCompleteWithInformation(Request, Status, (ULONG_PTR)Length);
}

VOID VirtVolEvtIoWrite(IN WDFQUEUE Queue, IN WDFREQUEST Request, IN size_t Length)
{
    PDEVICE_EXTENSION      devExt = QueueGetExtension(Queue)->DeviceExtension;
    NTSTATUS               Status = STATUS_INVALID_PARAMETER;
    WDF_REQUEST_PARAMETERS Parameters;
    LARGE_INTEGER          ByteOffset;
    WDFMEMORY              hMemory;
    __analysis_assume(Length > 0);
    WDF_REQUEST_PARAMETERS_INIT(&Parameters);
    WdfRequestGetParameters(Request, &Parameters);
    ByteOffset.QuadPart = Parameters.Parameters.Write.DeviceOffset;
    if (VirtVolCheckParameters(devExt, ByteOffset, Length)) {
        Status = WdfRequestRetrieveInputMemory(Request, &hMemory);
        if(NT_SUCCESS(Status)){
            Status = WdfMemoryCopyToBuffer(hMemory, 0, devExt->VolumeImage + ByteOffset.LowPart, Length);
        }
    }
    WdfRequestCompleteWithInformation(Request, Status, (ULONG_PTR)Length);
}

VOID VirtVolEvtIoDeviceControl(IN WDFQUEUE Queue, IN WDFREQUEST Request, IN size_t OutputBufferLength, IN size_t InputBufferLength, IN ULONG IoControlCode)
{
    NTSTATUS          Status = STATUS_INVALID_DEVICE_REQUEST;
    ULONG_PTR         information = 0;
    size_t            bufSize;
    PDEVICE_EXTENSION devExt = QueueGetExtension(Queue)->DeviceExtension;

    switch (IoControlCode) {
    case IOCTL_STORAGE_GET_DEVICE_NUMBER:
        if (OutputBufferLength < sizeof(STORAGE_DEVICE_NUMBER)) {
            Status = STATUS_BUFFER_TOO_SMALL;
            information = sizeof(STORAGE_DEVICE_NUMBER);
        } else {
            PSTORAGE_DEVICE_NUMBER number;

            Status = WdfRequestRetrieveOutputBuffer(Request, sizeof(STORAGE_DEVICE_NUMBER), &number, &bufSize);
            if (NT_SUCCESS(Status)) {
                number->DeviceType = FILE_DEVICE_DISK;
                number->DeviceNumber = devExt->StorNumber;
                number->PartitionNumber = (ULONG) (-1L);
                Status = STATUS_SUCCESS;
                information = sizeof(STORAGE_DEVICE_NUMBER);
            }            
        }
        break;
    case IOCTL_DISK_GET_LENGTH_INFO:
        if (OutputBufferLength < sizeof(GET_LENGTH_INFORMATION)) {
            Status = STATUS_BUFFER_TOO_SMALL;
            information = sizeof(GET_LENGTH_INFORMATION);
        } else {
            PGET_LENGTH_INFORMATION lengthInfo;

            Status = WdfRequestRetrieveOutputBuffer(Request, sizeof(GET_LENGTH_INFORMATION), &lengthInfo, &bufSize);
            if (NT_SUCCESS(Status)) {
                lengthInfo->Length.QuadPart = devExt->VirtvolRegInfo.StorSize;
                Status = STATUS_SUCCESS;
                information = sizeof(GET_LENGTH_INFORMATION);
            }
        }
        break;
    case IOCTL_DISK_GET_PARTITION_INFO: {
            PPARTITION_INFORMATION outputBuffer;
            PBOOT_SECTOR bootSector = (PBOOT_SECTOR) devExt->VolumeImage;
            information = sizeof(PARTITION_INFORMATION);
            Status = WdfRequestRetrieveOutputBuffer(Request, sizeof(PARTITION_INFORMATION), &outputBuffer, &bufSize);
            if(NT_SUCCESS(Status) ) {
                outputBuffer->PartitionType = (bootSector->bsFileSystemType[4] == '6') ? PARTITION_FAT_16 : PARTITION_FAT_12;
                outputBuffer->BootIndicator       = FALSE;
                outputBuffer->RecognizedPartition = TRUE;
                outputBuffer->RewritePartition    = FALSE;
                outputBuffer->StartingOffset.QuadPart = 0;
                outputBuffer->PartitionLength.QuadPart = devExt->VirtvolRegInfo.StorSize;
                outputBuffer->HiddenSectors       = (ULONG) (1L);
                outputBuffer->PartitionNumber     = (ULONG) (-1L);
                Status = STATUS_SUCCESS;
            }
        }
        break;
    case IOCTL_DISK_GET_PARTITION_INFO_EX: 
        if (OutputBufferLength < sizeof(PARTITION_INFORMATION_EX)) {
            Status = STATUS_BUFFER_TOO_SMALL;
            information = sizeof(PARTITION_INFORMATION_EX);
        } else {
            PPARTITION_INFORMATION_EX info;
            PBOOT_SECTOR bootSector = (PBOOT_SECTOR) devExt->VolumeImage;
            Status = WdfRequestRetrieveOutputBuffer(Request, sizeof(PARTITION_INFORMATION_EX), &info, &bufSize);
            if (NT_SUCCESS(Status)) {
                info->PartitionStyle = PARTITION_STYLE_MBR;
                info->StartingOffset.QuadPart = 0;
                info->PartitionLength.QuadPart = devExt->VirtvolRegInfo.StorSize;
                info->PartitionNumber = (ULONG) (-1L);
                info->RewritePartition = FALSE;
                info->Mbr.PartitionType = 
                    (bootSector->bsFileSystemType[4] == '6') ? PARTITION_FAT_16 : PARTITION_FAT_12;
                info->Mbr.BootIndicator = FALSE;
                info->Mbr.RecognizedPartition = TRUE;
                info->Mbr.HiddenSectors = (ULONG) (-1L);
                Status = STATUS_SUCCESS;
                information = sizeof(PARTITION_INFORMATION_EX);
            }            
        }
        break;
    case IOCTL_DISK_GET_DRIVE_GEOMETRY:  {
            PDISK_GEOMETRY outputBuffer;
            // Return the drive geometry for the virtual storage. Note that
            // we return values which were made up to suit the disk size.
            information = sizeof(DISK_GEOMETRY);
            Status = WdfRequestRetrieveOutputBuffer(Request, sizeof(DISK_GEOMETRY), &outputBuffer, &bufSize);
            if(NT_SUCCESS(Status) ) {
                RtlCopyMemory(outputBuffer, &(devExt->DiskGeometry), sizeof(DISK_GEOMETRY));
                Status = STATUS_SUCCESS;
            }
        }
        break;
    case IOCTL_DISK_CHECK_VERIFY:
    case IOCTL_DISK_IS_WRITABLE:
    case IOCTL_VOLUME_IS_DYNAMIC:
    case IOCTL_VOLUME_ONLINE:
        Status = STATUS_SUCCESS;
        break;
    case IOCTL_MOUNTDEV_QUERY_STABLE_GUID:
        if (OutputBufferLength < sizeof(MOUNTDEV_STABLE_GUID)) {
            Status = STATUS_BUFFER_TOO_SMALL;
            information = sizeof(MOUNTDEV_STABLE_GUID);
        } else {
            PMOUNTDEV_STABLE_GUID guid;
            Status = WdfRequestRetrieveOutputBuffer(Request, sizeof(MOUNTDEV_STABLE_GUID), &guid, &bufSize);
            if (NT_SUCCESS(Status)) {
                Status = STATUS_SUCCESS;
                guid->StableGuid = devExt->UniqueIdGuid;
                information = sizeof(MOUNTDEV_STABLE_GUID);
            }            
        }
        break;
    case IOCTL_MOUNTDEV_LINK_CREATED: {
        PMOUNTDEV_NAME name;
        if ( InputBufferLength >= sizeof(MOUNTDEV_NAME)) {
            Status = WdfRequestRetrieveInputBuffer(Request, sizeof(MOUNTDEV_NAME), &name, &bufSize);
            if (NT_SUCCESS(Status)) {
            }            
        }
        Status = STATUS_SUCCESS;
        break;
    }
    case IOCTL_VOLUME_GET_GPT_ATTRIBUTES:
        if ( OutputBufferLength < sizeof(VOLUME_GET_GPT_ATTRIBUTES_INFORMATION)) {
            Status = STATUS_BUFFER_TOO_SMALL;
            information = sizeof(VOLUME_GET_GPT_ATTRIBUTES_INFORMATION);
        } else {
            PVOLUME_GET_GPT_ATTRIBUTES_INFORMATION attrib;

            Status = WdfRequestRetrieveOutputBuffer(Request, sizeof(VOLUME_GET_GPT_ATTRIBUTES_INFORMATION), &attrib, &bufSize);
            if (NT_SUCCESS(Status)) {
                attrib = 0;
                Status = STATUS_SUCCESS;
                information = sizeof(VOLUME_GET_GPT_ATTRIBUTES_INFORMATION);
            }            
        }
        break;
    case IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS:
    {
        PVOLUME_DISK_EXTENTS diskExts;
        if ( OutputBufferLength < sizeof(VOLUME_DISK_EXTENTS)) {
            Status = STATUS_BUFFER_TOO_SMALL;
            information = sizeof(VOLUME_DISK_EXTENTS);
            DbgPrint("VirtVol IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS returning STATUS_BUFFER_TOO_SMALL\n");
            break;
        }
        Status = WdfRequestRetrieveOutputBuffer(Request, sizeof(VOLUME_DISK_EXTENTS), &diskExts, &bufSize);
        if (NT_SUCCESS(Status)) {       
            diskExts->NumberOfDiskExtents = 1;
            diskExts->Extents[0].DiskNumber = devExt->StorNumber;
            diskExts->Extents[0].StartingOffset.QuadPart = 0;
            diskExts->Extents[0].ExtentLength.QuadPart = devExt->VirtvolRegInfo.StorSize;
            Status = STATUS_SUCCESS;
            information = sizeof(VOLUME_DISK_EXTENTS);
        }
        break;
    }
    case IOCTL_MOUNTDEV_QUERY_SUGGESTED_LINK_NAME:
    {
        // if using auto-mount - uncomment this code, and #if 0 below code
        Status = STATUS_INVALID_DEVICE_REQUEST;
        information = 0;
        break;
    }
    case IOCTL_MOUNTDEV_QUERY_DEVICE_NAME: {
        PMOUNTDEV_NAME name;
        if ( OutputBufferLength < sizeof(MOUNTDEV_NAME)) {
            Status = STATUS_BUFFER_TOO_SMALL;
            information = sizeof(MOUNTDEV_NAME);
            break;
        }
        Status = WdfRequestRetrieveOutputBuffer(Request, sizeof(MOUNTDEV_NAME), &name, &bufSize);
        if (NT_SUCCESS(Status)) {       
            RtlZeroMemory(name, sizeof(MOUNTDEV_NAME));
            name->NameLength = devExt->NtDeviceName.Length;
            information = FIELD_OFFSET(MOUNTDEV_NAME, Name) + name->NameLength;
            if ( OutputBufferLength < information ) {
                Status = STATUS_BUFFER_OVERFLOW;
                information = FIELD_OFFSET(MOUNTDEV_NAME, Name);
                break;
            }
            RtlCopyMemory(name->Name, devExt->NtDeviceName.Buffer, devExt->NtDeviceName.Length);
            Status = STATUS_SUCCESS;
            DbgPrint("VirtVol IOCTL_MOUNTDEV_QUERY_DEVICE_NAME SUCCESS %ws\n", name->Name);
        }
        break;
    }
    case IOCTL_MOUNTDEV_QUERY_UNIQUE_ID: 
    {
		// Set the volume Unique ID to the symbolic link GUID that was returned when the driver registered
		// a GUID_DEVINTERFACE_VOLUME device interface (see the RegisterInterface function)
	    PMOUNTDEV_UNIQUE_ID uniqueId = NULL;
		Status = STATUS_SUCCESS;
	    if (!devExt->DeviceInterfaceSymbolicLink.Buffer) {
			information = 0;
	        Status = STATUS_INVALID_PARAMETER;
			break;
	    }
		if (OutputBufferLength < sizeof(MOUNTDEV_UNIQUE_ID)) {
			information = sizeof(MOUNTDEV_UNIQUE_ID);
	        Status = STATUS_BUFFER_TOO_SMALL;
			break;
	    }
	    Status = WdfRequestRetrieveOutputBuffer(Request, sizeof(MOUNTDEV_UNIQUE_ID), &uniqueId, NULL);
	    if (NT_SUCCESS(Status)) {
	        RtlZeroMemory(uniqueId, sizeof(MOUNTDEV_UNIQUE_ID));
	        uniqueId->UniqueIdLength = devExt->DeviceInterfaceSymbolicLink.Length;
	        if (OutputBufferLength < (sizeof(USHORT) + devExt->DeviceInterfaceSymbolicLink.Length)) {
				information = sizeof(MOUNTDEV_UNIQUE_ID);
				Status = STATUS_BUFFER_OVERFLOW;
				break;
			}
			RtlCopyMemory(uniqueId->UniqueId, devExt->DeviceInterfaceSymbolicLink.Buffer, uniqueId->UniqueIdLength);
			information = sizeof(USHORT)+ uniqueId->UniqueIdLength;
			Status = STATUS_SUCCESS;
	    }
	   	break;
    }
    case IOCTL_STORAGE_GET_HOTPLUG_INFO:
        if (OutputBufferLength < sizeof(STORAGE_HOTPLUG_INFO)) {
            Status = STATUS_BUFFER_TOO_SMALL;
            information = sizeof(STORAGE_HOTPLUG_INFO);
            break;
        } else {
            PSTORAGE_HOTPLUG_INFO info = NULL;
            Status = WdfRequestRetrieveOutputBuffer(Request, sizeof(STORAGE_HOTPLUG_INFO), &info, &bufSize);
            if (NT_SUCCESS(Status)) {       
                *info = devExt->StorHotPlug;
                Status = STATUS_SUCCESS;
                information = sizeof(STORAGE_HOTPLUG_INFO);
            }
        }
        break;
    default:
        break;
    }
    WdfRequestCompleteWithInformation(Request, Status, information);
}

VOID VirtVolEvtDeviceContextCleanup(IN WDFOBJECT Device)
{
    PDEVICE_EXTENSION pDeviceExtension = DeviceGetExtension(Device);
    if(pDeviceExtension->VolumeImage) {
        ExFreePool(pDeviceExtension->VolumeImage);
    }
	if(pDeviceExtension->DeviceInterfaceSymbolicLink.Buffer) {
        ExFreePool(pDeviceExtension->DeviceInterfaceSymbolicLink.Buffer);
    }
}

NTSTATUS VirtVolEvtDeviceAdd(IN WDFDRIVER Driver, IN PWDFDEVICE_INIT DeviceInit)
{
    WDF_OBJECT_ATTRIBUTES   deviceAttributes;
    WDF_PNPPOWER_EVENT_CALLBACKS    pnpPowerCallbacks;
    NTSTATUS                status;
    WDFDEVICE               device;
    WDF_OBJECT_ATTRIBUTES   queueAttributes;
    WDF_IO_QUEUE_CONFIG     ioQueueConfig;
    PDEVICE_EXTENSION       pDeviceExtension;
    PQUEUE_EXTENSION        pQueueContext = NULL;
    WDFQUEUE                queue;
    WCHAR                   VirtVolInstanceName[128];
    UNICODE_STRING          ntDeviceName;
    RtlStringCchPrintfW(VirtVolInstanceName, RTL_NUMBER_OF(VirtVolInstanceName), L"\\Device\\VirtVolFdo%d", ordinal);
    RtlInitUnicodeString(&ntDeviceName, VirtVolInstanceName);

    UNREFERENCED_PARAMETER(Driver);
    // Storage drivers have to name their FDOs. Since we are not unique'fying
    // the device name, we wouldn't be able to install more than one instance
    // of this VirtVol driver.
    status = WdfDeviceInitAssignName(DeviceInit, &ntDeviceName);
    if (!NT_SUCCESS(status)) {
        DbgPrint("WdfDeviceInitAssignName failed %x\n", status);
        return status;
    }
    status = WdfDeviceInitAssignSDDLString(DeviceInit, &SDDL_DEVOBJ_SYS_ALL_ADM_ALL_WORLD_ALL_RES_ALL);
    if (!NT_SUCCESS(status)) {
        DbgPrint("WdfDeviceInitAssignSDDLString failed %x\n", status);
        return status;
    }
    WDF_PNPPOWER_EVENT_CALLBACKS_INIT(&pnpPowerCallbacks);
    pnpPowerCallbacks.EvtDevicePrepareHardware = VirtVolEvtDevicePrepareHardware;
    pnpPowerCallbacks.EvtDeviceD0Entry         = VirtVolEvtDeviceD0Entry;
    pnpPowerCallbacks.EvtDeviceReleaseHardware = VirtVolEvtDeviceReleaseHardware;
    WdfDeviceInitSetPnpPowerEventCallbacks(DeviceInit, &pnpPowerCallbacks);    
    WdfDeviceInitSetDeviceType(DeviceInit, FILE_DEVICE_DISK);
    WdfDeviceInitSetIoType(DeviceInit, WdfDeviceIoDirect);
    WdfDeviceInitSetExclusive(DeviceInit, FALSE);
    // Since this is a pure software only driver, there is no need to register
    // any PNP/Power event callbacks. Framework will respond to these
    // events appropriately.
    WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(&deviceAttributes, DEVICE_EXTENSION);
    deviceAttributes.EvtCleanupCallback = VirtVolEvtDeviceContextCleanup;
    status = WdfDeviceCreate(&DeviceInit, &deviceAttributes, &device);
    if (!NT_SUCCESS(status)) {
        return status;
    }
    // Now that the WDF device object has been created, set up any context
    // that it requires.
    pDeviceExtension = DeviceGetExtension(device);
    // Configure a default queue so that requests that are not
    // configure-fowarded using WdfDeviceConfigureRequestDispatching to goto
    // other queues get dispatched here.
    WDF_IO_QUEUE_CONFIG_INIT_DEFAULT_QUEUE (&ioQueueConfig, WdfIoQueueDispatchSequential);
    ioQueueConfig.EvtIoDeviceControl = VirtVolEvtIoDeviceControl;
    ioQueueConfig.EvtIoRead          = VirtVolEvtIoRead;
    ioQueueConfig.EvtIoWrite         = VirtVolEvtIoWrite;
    WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(&queueAttributes, QUEUE_EXTENSION);
    status = WdfIoQueueCreate(device, &ioQueueConfig, &queueAttributes, &queue);
    if (!NT_SUCCESS(status)) {
        return status;
    }
    pQueueContext = QueueGetExtension(queue);
    // Set the context for our default queue as our device extension.
    pQueueContext->DeviceExtension = pDeviceExtension;
    // Now do any Virtual volume specific initialization
    pDeviceExtension->VirtvolRegInfo.DriveLetter.Buffer = (PWSTR) &pDeviceExtension->DriveLetterBuffer;
    pDeviceExtension->VirtvolRegInfo.DriveLetter.MaximumLength = sizeof(pDeviceExtension->DriveLetterBuffer);
    // Get the volume parameters from the registry
    VirtVolQueryVolumeRegParameters( WdfDriverGetRegistryPath(WdfDeviceGetDriver(device)), &pDeviceExtension->VirtvolRegInfo);
    // Allocate memory for the volume image.
    pDeviceExtension->VolumeImage = ExAllocatePoolWithTag( NonPagedPool, pDeviceExtension->VirtvolRegInfo.StorSize, VIRTVOL_TAG);
    if (pDeviceExtension->VolumeImage) {
        UNICODE_STRING ntName;
        VirtVolFormatVolume(pDeviceExtension);
        // hotplug information.
        pDeviceExtension->StorHotPlug.Size = sizeof(STORAGE_HOTPLUG_INFO);
        pDeviceExtension->StorHotPlug.MediaRemovable = TRUE;
        pDeviceExtension->StorHotPlug.MediaHotplug = TRUE;
        pDeviceExtension->StorHotPlug.DeviceHotplug =TRUE;
        pDeviceExtension->StorHotPlug.WriteCacheEnableOverride=FALSE;
        pDeviceExtension->DriveLayoutInfo.PartitionStyle= PARTITION_STYLE_MBR;
        pDeviceExtension->DriveLayoutInfo.PartitionCount= 1;
        pDeviceExtension->DriveLayoutInfo.Mbr.Signature = ordinal;
        pDeviceExtension->DriveLayoutInfo.PartitionEntry[0].PartitionStyle = PARTITION_STYLE_MBR;
        pDeviceExtension->DriveLayoutInfo.PartitionEntry[0].StartingOffset.QuadPart = 0;
        pDeviceExtension->DriveLayoutInfo.PartitionEntry[0].PartitionLength.QuadPart = pDeviceExtension->VirtvolRegInfo.StorSize;
        pDeviceExtension->DriveLayoutInfo.PartitionEntry[0].PartitionNumber   = (ULONG) (1L);
        pDeviceExtension->DriveLayoutInfo.PartitionEntry[0].RewritePartition  = FALSE;
        pDeviceExtension->StorNumber = 99 + ordinal;
        status = ExUuidCreate(&pDeviceExtension->UniqueIdGuid);
        status = STATUS_SUCCESS;
        // Now create a symbolic link for the drive letter.
        RtlInitUnicodeString(&ntName, VirtVolInstanceName);
        pDeviceExtension->NtDeviceName.Buffer = (PWSTR) &pDeviceExtension->NtDeviceNameBuffer;
        pDeviceExtension->NtDeviceName.MaximumLength = sizeof(pDeviceExtension->NtDeviceNameBuffer);
        pDeviceExtension->NtDeviceName.Length = ntName.Length;
        RtlCopyUnicodeString(&pDeviceExtension->NtDeviceName, &ntName);
    }
    ordinal++;
    return status;
}

VOID VirtVolQueryVolumeRegParameters(__in PWSTR RegistryPath, __in PVIRTVOL_INFO VirtvolRegInfo)
/*++

Routine Description:

    This routine is called from the DriverEntry to get the debug
    parameters from the registry. If the registry query fails, then
    default values are used.

Arguments:

    RegistryPath    - Points the service path to get the registry parameters

Return Value:

    None

--*/

{

    RTL_QUERY_REGISTRY_TABLE rtlQueryRegTbl[5 + 1];  // Need 1 for NULL
    NTSTATUS                 Status;
    VIRTVOL_INFO             defVirtvolRegInfo;

    ASSERT(RegistryPath != NULL);
    // Set the default values
    defVirtvolRegInfo.StorSize          = DEFAULT_VOL_SIZE;
    defVirtvolRegInfo.RootDirEntries    = DEFAULT_ROOT_DIR_ENTRIES;
    defVirtvolRegInfo.SectorsPerCluster = DEFAULT_SECTORS_PER_CLUSTER;
    RtlInitUnicodeString(&defVirtvolRegInfo.DriveLetter, DEFAULT_DRIVE_LETTER);
    RtlZeroMemory(rtlQueryRegTbl, sizeof(rtlQueryRegTbl));
    // Setup the query table
    rtlQueryRegTbl[0].Flags         = RTL_QUERY_REGISTRY_SUBKEY;
    rtlQueryRegTbl[0].Name          = L"Parameters";
    rtlQueryRegTbl[0].EntryContext  = NULL;
    rtlQueryRegTbl[0].DefaultType   = (ULONG_PTR)NULL;
    rtlQueryRegTbl[0].DefaultData   = NULL;
    rtlQueryRegTbl[0].DefaultLength = (ULONG_PTR)NULL;
    // Volume paramters
    rtlQueryRegTbl[1].Flags         = RTL_QUERY_REGISTRY_DIRECT;
    rtlQueryRegTbl[1].Name          = L"DiskSize";
    rtlQueryRegTbl[1].EntryContext  = &VirtvolRegInfo->StorSize;
    rtlQueryRegTbl[1].DefaultType   = REG_DWORD;
    rtlQueryRegTbl[1].DefaultData   = &defVirtvolRegInfo.StorSize;
    rtlQueryRegTbl[1].DefaultLength = sizeof(ULONG);

    rtlQueryRegTbl[2].Flags         = RTL_QUERY_REGISTRY_DIRECT;
    rtlQueryRegTbl[2].Name          = L"RootDirEntries";
    rtlQueryRegTbl[2].EntryContext  = &VirtvolRegInfo->RootDirEntries;
    rtlQueryRegTbl[2].DefaultType   = REG_DWORD;
    rtlQueryRegTbl[2].DefaultData   = &defVirtvolRegInfo.RootDirEntries;
    rtlQueryRegTbl[2].DefaultLength = sizeof(ULONG);

    rtlQueryRegTbl[3].Flags         = RTL_QUERY_REGISTRY_DIRECT;
    rtlQueryRegTbl[3].Name          = L"SectorsPerCluster";
    rtlQueryRegTbl[3].EntryContext  = &VirtvolRegInfo->SectorsPerCluster;
    rtlQueryRegTbl[3].DefaultType   = REG_DWORD;
    rtlQueryRegTbl[3].DefaultData   = &defVirtvolRegInfo.SectorsPerCluster;
    rtlQueryRegTbl[3].DefaultLength = sizeof(ULONG);

    rtlQueryRegTbl[4].Flags         = RTL_QUERY_REGISTRY_DIRECT;
    rtlQueryRegTbl[4].Name          = L"DriveLetter";
    rtlQueryRegTbl[4].EntryContext  = &VirtvolRegInfo->DriveLetter;
    rtlQueryRegTbl[4].DefaultType   = REG_SZ;
    rtlQueryRegTbl[4].DefaultData   = defVirtvolRegInfo.DriveLetter.Buffer;
    rtlQueryRegTbl[4].DefaultLength = 0;
    Status = RtlQueryRegistryValues( RTL_REGISTRY_ABSOLUTE | RTL_REGISTRY_OPTIONAL, RegistryPath, rtlQueryRegTbl, NULL, NULL);
    if (NT_SUCCESS(Status) == FALSE) {
        VirtvolRegInfo->StorSize          = defVirtvolRegInfo.StorSize;
        VirtvolRegInfo->RootDirEntries    = defVirtvolRegInfo.RootDirEntries;
        VirtvolRegInfo->SectorsPerCluster = defVirtvolRegInfo.SectorsPerCluster;
        RtlCopyUnicodeString(&VirtvolRegInfo->DriveLetter, &defVirtvolRegInfo.DriveLetter);
    }
    return;
}

NTSTATUS VirtVolFormatVolume(IN PDEVICE_EXTENSION devExt)
{

    PBOOT_SECTOR bootSector = (PBOOT_SECTOR) devExt->VolumeImage;
    PUCHAR       firstFatSector;
    ULONG        rootDirEntries;
    ULONG        sectorsPerCluster;
    USHORT       fatType;        // Type FAT 12 or 16
    USHORT       fatEntries;     // Number of cluster entries in FAT
    USHORT       fatSectorCnt;   // Number of sectors for FAT
    PDIR_ENTRY   rootDir;        // Pointer to first entry in root dir

    ASSERT(sizeof(BOOT_SECTOR) == 512);
    ASSERT(devExt->VolumeImage != NULL);

    RtlZeroMemory(devExt->VolumeImage, devExt->VirtvolRegInfo.StorSize);
    devExt->DiskGeometry.BytesPerSector = 512;
    devExt->DiskGeometry.SectorsPerTrack = 32;     // Using VirtVol value
    devExt->DiskGeometry.TracksPerCylinder = 2;    // Using VirtVol value

    // Calculate number of cylinders.
    devExt->DiskGeometry.Cylinders.QuadPart = devExt->VirtvolRegInfo.StorSize / 512 / 32 / 2;

    // Our media type is VIRTVOL_MEDIA_TYPE
    devExt->DiskGeometry.MediaType = VIRTVOL_MEDIA_TYPE;
    rootDirEntries = devExt->VirtvolRegInfo.RootDirEntries;
    sectorsPerCluster = devExt->VirtvolRegInfo.SectorsPerCluster;

    // Round Root Directory entries up if necessary
    if (rootDirEntries & (DIR_ENTRIES_PER_SECTOR - 1)) {
        rootDirEntries = (rootDirEntries + (DIR_ENTRIES_PER_SECTOR - 1)) & ~ (DIR_ENTRIES_PER_SECTOR - 1);
    }
    // We need to have the 0xeb and 0x90 since this is one of the
    // checks the file system recognizer uses
    bootSector->bsJump[0] = 0xeb;
    bootSector->bsJump[1] = 0x3c;
    bootSector->bsJump[2] = 0x90;
    // Set OemName to "RajuRam "
    // NOTE: Fill all 8 characters, eg. sizeof(bootSector->bsOemName);
    bootSector->bsOemName[0] = 'R';
    bootSector->bsOemName[1] = 'a';
    bootSector->bsOemName[2] = 'j';
    bootSector->bsOemName[3] = 'u';
    bootSector->bsOemName[4] = 'R';
    bootSector->bsOemName[5] = 'a';
    bootSector->bsOemName[6] = 'm';
    bootSector->bsOemName[7] = ' ';
    bootSector->bsBytesPerSec = (SHORT)devExt->DiskGeometry.BytesPerSector;
    bootSector->bsResSectors  = 1;
    bootSector->bsFATs        = 1;
    bootSector->bsRootDirEnts = (USHORT)rootDirEntries;
    bootSector->bsSectors     = (USHORT)(devExt->VirtvolRegInfo.StorSize / devExt->DiskGeometry.BytesPerSector);
    bootSector->bsMedia       = (UCHAR)devExt->DiskGeometry.MediaType;
    bootSector->bsSecPerClus  = (UCHAR)sectorsPerCluster;
    // Calculate number of sectors required for FAT
    fatEntries = (bootSector->bsSectors - bootSector->bsResSectors - bootSector->bsRootDirEnts / DIR_ENTRIES_PER_SECTOR) / bootSector->bsSecPerClus + 2;
    // Choose between 12 and 16 bit FAT based on number of clusters we
    // need to map
    if (fatEntries > 4087) {
        fatType =  16;
        fatSectorCnt = (fatEntries * 2 + 511) / 512;
        fatEntries   = fatEntries + fatSectorCnt;
        fatSectorCnt = (fatEntries * 2 + 511) / 512;
    } else {
        fatType =  12;
        fatSectorCnt = (((fatEntries * 3 + 1) / 2) + 511) / 512;
        fatEntries   = fatEntries + fatSectorCnt;
        fatSectorCnt = (((fatEntries * 3 + 1) / 2) + 511) / 512;
    }
    bootSector->bsFATsecs       = fatSectorCnt;
    bootSector->bsSecPerTrack   = (USHORT)devExt->DiskGeometry.SectorsPerTrack;
    bootSector->bsHeads         = (USHORT)devExt->DiskGeometry.TracksPerCylinder;
    bootSector->bsBootSignature = 0x29;
    bootSector->bsVolumeID      = 0x12345678;
    // Set Label to "VirtVol    "
    // NOTE: Fill all 11 characters, eg. sizeof(bootSector->bsLabel);
    bootSector->bsLabel[0]  = 'V';
    bootSector->bsLabel[1]  = 'i';
    bootSector->bsLabel[2]  = 'r';
    bootSector->bsLabel[3]  = 't';
    bootSector->bsLabel[4]  = 'V';
    bootSector->bsLabel[5]  = 'o';
    bootSector->bsLabel[6]  = 'l';
    bootSector->bsLabel[7]  = ' ';
    bootSector->bsLabel[8]  = ' ';
    bootSector->bsLabel[9]  = ' ';
    bootSector->bsLabel[10] = ' ';
    // Set FileSystemType to "FAT1?   "
    // NOTE: Fill all 8 characters, eg. sizeof(bootSector->bsFileSystemType);
    bootSector->bsFileSystemType[0] = 'F';
    bootSector->bsFileSystemType[1] = 'A';
    bootSector->bsFileSystemType[2] = 'T';
    bootSector->bsFileSystemType[3] = '1';
    bootSector->bsFileSystemType[4] = '?';
    bootSector->bsFileSystemType[5] = ' ';
    bootSector->bsFileSystemType[6] = ' ';
    bootSector->bsFileSystemType[7] = ' ';
    bootSector->bsFileSystemType[4] = ( fatType == 16 ) ? '6' : '2';
    bootSector->bsSig2[0] = 0x55;
    bootSector->bsSig2[1] = 0xAA;
    // The FAT is located immediately following the boot sector.
    firstFatSector    = (PUCHAR)(bootSector + 1);
    firstFatSector[0] = (UCHAR)devExt->DiskGeometry.MediaType;
    firstFatSector[1] = 0xFF;
    firstFatSector[2] = 0xFF;
    if (fatType == 16) {
        firstFatSector[3] = 0xFF;
    }
    // The Root Directory follows the FAT
    rootDir = (PDIR_ENTRY)(bootSector + 1 + fatSectorCnt);
    // Set device name to "MS-VIRTV"
    // NOTE: Fill all 8 characters, eg. sizeof(rootDir->deName);
    rootDir->deName[0] = 'M';
    rootDir->deName[1] = 'S';
    rootDir->deName[2] = '-';
    rootDir->deName[3] = 'V';
    rootDir->deName[4] = 'I';
    rootDir->deName[5] = 'R';
    rootDir->deName[6] = 'T';
    rootDir->deName[7] = 'V';
    // Set device extension name to "OL."
    // NOTE: Fill all 3 characters, eg. sizeof(rootDir->deExtension);
    //
    rootDir->deExtension[0] = 'O';
    rootDir->deExtension[1] = 'L';
    rootDir->deExtension[2] = '.';
    rootDir->deAttributes = DIR_ATTR_VOLUME;
    return STATUS_SUCCESS;
}

BOOLEAN VirtVolCheckParameters(IN PDEVICE_EXTENSION devExt, IN LARGE_INTEGER ByteOffset, IN size_t Length)
{
    // Check for invalid parameters.  It is an error for the starting offset
    // + length to go past the end of the buffer, or for the length to
    // not be a proper multiple of the sector size.
    //
    // Others are possible, but we don't check them since we trust the
    // file system.
    //
    if( devExt->VirtvolRegInfo.StorSize < Length ||
        ByteOffset.QuadPart < 0 || // QuadPart is signed so check for negative values
        ((ULONGLONG)ByteOffset.QuadPart > (devExt->VirtvolRegInfo.StorSize - Length)) ||
            (Length & (devExt->DiskGeometry.BytesPerSector - 1))) {
        KdPrint(( "Error invalid parameter\n" "ByteOffset: %I64x\n" "Length: %d\n", ByteOffset.QuadPart, Length));
        return FALSE;
    }
    return TRUE;
}

VOID VirtVolEvtDriverUnload(IN WDFDRIVER        Driver)
{
    DbgPrint("VirtVolEvtDriverUnload: \n");
    UNREFERENCED_PARAMETER(Driver);
    return;
}

NTSTATUS RegisterInterface(IN WDFDEVICE       Device)
{
    NTSTATUS status;
    LPGUID   interfaceGuid = NULL;
    PDEVICE_EXTENSION devExt;
	UNICODE_STRING DeviceInterfaceSymbolicLink;
	WDFSTRING  DeviceInterfaceSymbolicLinkStringHandle;
    devExt = DeviceGetExtension(Device);
    interfaceGuid = (LPGUID)&GUID_DEVINTERFACE_VOLUME;
	// Create a GUID_DEVINTERFACE_VOLUME device interface for our VirtVol device
	status = WdfDeviceCreateDeviceInterface(Device, interfaceGuid, NULL);
	if (NT_SUCCESS(status)) {
		// Retrieve the symbolic link name (a GUID) that the system assigned to the device interface registered for the VirtVol device
		// and save it in the device extension for later use
		status = WdfStringCreate( NULL, WDF_NO_OBJECT_ATTRIBUTES, &DeviceInterfaceSymbolicLinkStringHandle);
		if (!NT_SUCCESS(status)){
			return status;
		}
		status = WdfDeviceRetrieveDeviceInterfaceString( Device, interfaceGuid, NULL, DeviceInterfaceSymbolicLinkStringHandle);
		if (!NT_SUCCESS(status)){
			return status;
		}
		WdfStringGetUnicodeString( DeviceInterfaceSymbolicLinkStringHandle, &DeviceInterfaceSymbolicLink);
		devExt->DeviceInterfaceSymbolicLink.MaximumLength = DeviceInterfaceSymbolicLink.Length + sizeof(UNICODE_NULL);
		devExt->DeviceInterfaceSymbolicLink.Length = DeviceInterfaceSymbolicLink.Length;
		devExt->DeviceInterfaceSymbolicLink.Buffer = ExAllocatePoolWithTag ( NonPagedPool, devExt->DeviceInterfaceSymbolicLink.MaximumLength, VIRTVOL_TAG);
		if (NULL == devExt->DeviceInterfaceSymbolicLink.Buffer) {
			return STATUS_INSUFFICIENT_RESOURCES;
		}
		RtlCopyUnicodeString(&devExt->DeviceInterfaceSymbolicLink, &DeviceInterfaceSymbolicLink);
		// Enable the device interface registered for the virtvol device
        WdfDeviceSetDeviceInterfaceState(Device, interfaceGuid, NULL, TRUE);
    }
    return status;
	
}

NTSTATUS RegisterMountMgr(PDEVICE_EXTENSION devExt)
{
    NTSTATUS status = STATUS_SUCCESS;
    UNICODE_STRING mountMgrName;
    PFILE_OBJECT mountMgrFileObject = NULL;
    PDEVICE_OBJECT mountMgrDeviceObject = NULL;
    PMOUNTMGR_TARGET_NAME mntName = NULL;
    KEVENT event;
    ULONG mntNameLength = 0;

    RtlInitUnicodeString(&mountMgrName, MOUNTMGR_DEVICE_NAME);
    status = IoGetDeviceObjectPointer(&mountMgrName, FILE_READ_ATTRIBUTES, &mountMgrFileObject, &mountMgrDeviceObject);
    if (NT_SUCCESS(status)) {
        PIRP irp;
        IO_STATUS_BLOCK statusBlock;
        mntNameLength = sizeof(MOUNTMGR_TARGET_NAME) + devExt->NtDeviceName.Length;
        mntName = ExAllocatePoolWithTag(NonPagedPool, mntNameLength, 'oecd');
        if (NULL == mntName) {
            return STATUS_INSUFFICIENT_RESOURCES;
        }
        mntName->DeviceNameLength = devExt->NtDeviceName.Length;
        RtlCopyMemory(mntName->DeviceName, devExt->NtDeviceName.Buffer, devExt->NtDeviceName.Length);
        KeInitializeEvent(&event, NotificationEvent, FALSE);
        irp = IoBuildDeviceIoControlRequest( IOCTL_MOUNTMGR_VOLUME_ARRIVAL_NOTIFICATION, mountMgrDeviceObject, mntName, mntNameLength, NULL, 0, FALSE, &event, &statusBlock);
        if (irp) {
            status = IoCallDriver(mountMgrDeviceObject, irp);
            if (status == STATUS_PENDING) {
                status = KeWaitForSingleObject(&event, Executive, KernelMode, FALSE, NULL);
            }
        }
    }
    if (mntName) {
        ExFreePool(mntName);
    }
    return status;
}

NTSTATUS VirtVolEvtDevicePrepareHardware(IN WDFDEVICE Device, IN WDFCMRESLIST ResourcesRaw, IN WDFCMRESLIST ResourcesTranslated)
{
    PDEVICE_EXTENSION devExt;
    UNREFERENCED_PARAMETER(ResourcesRaw);
    UNREFERENCED_PARAMETER(ResourcesTranslated);
    devExt = DeviceGetExtension(Device);
    return STATUS_SUCCESS;
}

NTSTATUS VirtVolEvtDeviceReleaseHardware(IN WDFDEVICE Device, IN WDFCMRESLIST ResourceListTranslated)
{
    UNREFERENCED_PARAMETER(Device);
    UNREFERENCED_PARAMETER(ResourceListTranslated);
    return STATUS_SUCCESS;
}

NTSTATUS VirtVolEvtDeviceD0Entry(IN WDFDEVICE Device, IN WDF_POWER_DEVICE_STATE PreviousState)
{
    NTSTATUS status;
    PDEVICE_EXTENSION devExt;
    UNREFERENCED_PARAMETER(PreviousState);
    devExt = DeviceGetExtension(Device);
    status = CreateMountMgrWorkItem(Device);
    return STATUS_SUCCESS;
   
}

VOID RegisterMountMgrWorkItem(WDFWORKITEM WorkItem)
{
    WDFDEVICE device;
    PDEVICE_EXTENSION devExt;
    device = WdfWorkItemGetParentObject(WorkItem);
    devExt = DeviceGetExtension(device);
    RegisterMountMgr(devExt);
    RegisterInterface(device);

}

NTSTATUS CreateMountMgrWorkItem(WDFDEVICE device)
{
    NTSTATUS status;
    WDF_WORKITEM_CONFIG workitemConfig;
    WDF_OBJECT_ATTRIBUTES attributes;
    WDF_OBJECT_ATTRIBUTES_INIT(&attributes);
    attributes.ParentObject = device;
    WDF_WORKITEM_CONFIG_INIT(&workitemConfig, RegisterMountMgrWorkItem);
    status = WdfWorkItemCreate(&workitemConfig, &attributes, &g_WorkItemRegisterMountMgr);
    if (!NT_SUCCESS(status)) {
       return status;
    }
    WdfWorkItemEnqueue(g_WorkItemRegisterMountMgr);
    return status;
}